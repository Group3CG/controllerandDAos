package com.capgemini.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.dao.UserDao;
import com.capgemini.dao.UsrDaoImpl;
import com.capgemini.dto.Employee;
import com.capgemini.exception.EmsException;

/**
 * Servlet implementation class DirectController
 */
@WebServlet("/DirectController")
public class DirectController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, EmsException {

		EmployeeDao empDao = new EmployeeDaoImpl();
		UserDao userDao = new UsrDaoImpl();
		/* Service object*/
		String action = request.getParameter("action");
		String searchType = request.getParameter("searchType");
		switch(action) {
		/*case "login": {
			String usrName = request.getParameter("usrName");
			String usrPass = request.getParameter("usrPass");
//			String usrType="admin";
			String usrType = userDao.usrCheck(usrName,usrPass);
			System.out.println(usrType);
				Must return type of user or null if invalid user

			if(usrType.isEmpty()) {
				request.setAttribute("errMsg", "Invalid username/password");
				request.getRequestDispatcher("EMS_003_error_page.jsp").forward(request, response);
				break;
			}
			else {
				request.setAttribute("usrName", usrName);
				HttpSession session = request.getSession(true);
				if(usrType.equalsIgnoreCase("admin")) {
					
					request.getRequestDispatcher("EMS_001_adminMainScreen.jsp").forward(request, response);
				}
				else if(usrType.equalsIgnoreCase("user")) {
					request.getRequestDispatcher("EMS_002_userMainScreen.jsp").forward(request, response);
				}
			}
		}
		break;*/
//		case "usrSearch": {
//			switch(searchType) {
//			case "id": {
//				String usrId = request.getParameter("id");
//				Map<String,String> usrMap = new HashMap<>();
//				usrMap = serviceObj.serviceMethod(usrId);
//
//				if(usrMap == null) {
//					request.setAttribute("errMsg", "No employees with that id");
//					request.getRequestDispatcher("errorScreenUser").forward(request, response);
//					break;
//				}
//				else {
//					request.setAttribute("usrId", usrMap.get("empId"));
//					request.setAttribute("usrfName", usrMap.get("empfName"));
//					request.setAttribute("usrlName", usrMap.get("emplName"));
//					request.setAttribute("usrDOB", usrMap.get("empDOB"));
//					request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
//					request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
//					request.setAttribute("usrGrade", usrMap.get("empGrade"));
//					request.setAttribute("usrDesig", usrMap.get("empDesig"));
//					request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
//					request.setAttribute("usrGender", usrMap.get("empGender"));
//					request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
//					request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
//					request.setAttribute("usrConNum", usrMap.get("empConNum"));
//
//					request.getRequestDispatcher("displayScreenUser").forward(request, response);
//					break;
//				}
//			}
//			break;
//			case "fName": {
//					String fName = request.getParameter("fName");
//					Map<String,String> usrMap = new HashMap<>();
//					usrMap = serviceObj.serviceMethod(fName);
//	
//					if(usrMap == null) {
//						request.setAttribute("errMsg", "No employees with that first name");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					else {
//						request.setAttribute("usrId", usrMap.get("empId"));
//						request.setAttribute("usrfName", usrMap.get("empfName"));
//						request.setAttribute("usrlName", usrMap.get("emplName"));
//						request.setAttribute("usrDOB", usrMap.get("empDOB"));
//						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
//						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
//						request.setAttribute("usrGrade", usrMap.get("empGrade"));
//						request.setAttribute("usrDesig", usrMap.get("empDesig"));
//						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
//						request.setAttribute("usrGender", usrMap.get("empGender"));
//						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
//						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
//						request.setAttribute("usrConNum", usrMap.get("empConNum"));
//	
//						request.getRequestDispatcher("displayScreenUser").forward(request, response);
//						break;
//				}
//			}
//			break;
//			case "lName": {
//					String lName = request.getParameter("lName");
//					Map<String,String> usrMap = new HashMap<>();
//					usrMap = serviceObj.serviceMethod(lName);
//	
//					if(usrMap == null) {
//						request.setAttribute("errMsg", "No employees with that last name");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					else {
//						request.setAttribute("usrId", usrMap.get("empId"));
//						request.setAttribute("usrfName", usrMap.get("empfName"));
//						request.setAttribute("usrlName", usrMap.get("emplName"));
//						request.setAttribute("usrDOB", usrMap.get("empDOB"));
//						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
//						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
//						request.setAttribute("usrGrade", usrMap.get("empGrade"));
//						request.setAttribute("usrDesig", usrMap.get("empDesig"));
//						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
//						request.setAttribute("usrGender", usrMap.get("empGender"));
//						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
//						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
//						request.setAttribute("usrConNum", usrMap.get("empConNum"));
//	
//						request.getRequestDispatcher("displayScreenUser").forward(request, response);
//						break;
//				}
//			}
//			break;
//			case "dept": {
//					List<String> dept=new ArrayList<String>();
//					String values[] = request.getParameterValues("dept");
//					if(values!=null) {
//						for(int i=0;i<values.length;i++) {
//							dept.add(values[i]);
//						}
//					}
//					else {
//						request.setAttribute("errMsg", "No department selected");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					
//					Map<String,String> usrMap = new HashMap<>();
//					usrMap = serviceObj.serviceMethod(dept);
//
//					if(usrMap == null) {
//						request.setAttribute("errMsg", "No employees in selected department(s)");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					else {
//						request.setAttribute("usrId", usrMap.get("empId"));
//						request.setAttribute("usrfName", usrMap.get("empfName"));
//						request.setAttribute("usrlName", usrMap.get("emplName"));
//						request.setAttribute("usrDOB", usrMap.get("empDOB"));
//						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
//						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
//						request.setAttribute("usrGrade", usrMap.get("empGrade"));
//						request.setAttribute("usrDesig", usrMap.get("empDesig"));
//						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
//						request.setAttribute("usrGender", usrMap.get("empGender"));
//						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
//						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
//						request.setAttribute("usrConNum", usrMap.get("empConNum"));
//
//						request.getRequestDispatcher("displayScreenUser").forward(request, response);
//						break;
//				}
//			}
//			break;
//			case "grade": {
//				List<String> grade=new ArrayList<String>();
//				String values[] = request.getParameterValues("grade");
//				if(values!=null) {
//					for(int i=0;i<values.length;i++) {
//						grade.add(values[i]);
//					}
//				}
//					else {
//						request.setAttribute("errMsg", "No grade selected");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					
//					Map<String,String> usrMap = new HashMap<>();
//					usrMap = serviceObj.serviceMethod(grade);
//	
//					if(usrMap == null) {
//						request.setAttribute("errMsg", "No employees with selected grade(s)");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					else {
//						request.setAttribute("usrId", usrMap.get("empId"));
//						request.setAttribute("usrfName", usrMap.get("empfName"));
//						request.setAttribute("usrlName", usrMap.get("emplName"));
//						request.setAttribute("usrDOB", usrMap.get("empDOB"));
//						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
//						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
//						request.setAttribute("usrGrade", usrMap.get("empGrade"));
//						request.setAttribute("usrDesig", usrMap.get("empDesig"));
//						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
//						request.setAttribute("usrGender", usrMap.get("empGender"));
//						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
//						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
//						request.setAttribute("usrConNum", usrMap.get("empConNum"));
//	
//						request.getRequestDispatcher("displayScreenUser").forward(request, response);
//						break;
//				}
//			}
//			break;
//			case "maritalStatus": {
//					List<String> marStat=new ArrayList<String>();
//					String values[] = request.getParameterValues("marStat");
//					if(values!=null) {
//						for(int i=0;i<values.length;i++) {
//							marStat.add(values[i]);
//						}
//					}
//					else {
//						request.setAttribute("errMsg", "No maritial status selected");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					
//					Map<String,String> usrMap = new HashMap<>();
//					usrMap = serviceObj.serviceMethod(marStat);
//	
//					if(usrMap == null) {
//						request.setAttribute("errMsg", "No employees with selected maritial status");
//						request.getRequestDispatcher("errorScreenUser").forward(request, response);
//						break;
//					}
//					else {
//						request.setAttribute("usrId", usrMap.get("empId"));
//						request.setAttribute("usrfName", usrMap.get("empfName"));
//						request.setAttribute("usrlName", usrMap.get("emplName"));
//						request.setAttribute("usrDOB", usrMap.get("empDOB"));
//						request.setAttribute("usrDOJ", usrMap.get("empDOJ"));
//						request.setAttribute("usrDeptId", usrMap.get("empDeptId"));
//						request.setAttribute("usrGrade", usrMap.get("empGrade"));
//						request.setAttribute("usrDesig", usrMap.get("empDesig"));
//						request.setAttribute("usrBasicPay", usrMap.get("empBasicPay"));
//						request.setAttribute("usrGender", usrMap.get("empGender"));
//						request.setAttribute("usrMaritalStatus", usrMap.get("empMaritalStatus"));
//						request.setAttribute("usrHoAddr", usrMap.get("empHoAddr"));
//						request.setAttribute("usrConNum", usrMap.get("empConNum"));
//	
//						request.getRequestDispatcher("displayScreenUser").forward(request, response);
//						break;
//				}
//			}//close of inner case
//			}//close of inner switch
//		}//close of outer case
//		case "adminChoice" : {
//				String adminChoice = request.getParameter("choice");
//				
//				switch(adminChoice) {
//				case "add" : {
//					List<String> deptNames = new ArrayList<>();
//					deptNames = serviceObj.serviceMethod();
//					request.setAttribute("ListOfDepts", deptNames);
//					request.getRequestDispatcher("addNewUser").forward(request, response);
//					}
//				break;
//				case "modify": {
//					request.getRequestDispatcher("modifyUser").forward(request, response);	
//					}
//				break;
//				case "display": {
//					//find way to fetch 10 user at a time while service sends a list of n users
//					request.getRequestDispatcher("modifyUser").forward(request, response);
//					}
//				break;
//				}
			//}
//		break;*/
		case "addNewUser":
				Employee emp = new Employee();
					
					emp.setEmp_First_Name(request.getParameter("fName"));
					emp.setEmp_Last_Name(request.getParameter("lName"));
					emp.setEmp_Date_of_Joining(request.getParameter("doj")); //to be changed to date type in sql
					emp.setEmp_Date_of_Birth(request.getParameter("dob"));
					emp.setEmp_Dept_Id(Integer.parseInt(request.getParameter("dept")));
					emp.setEmp_Grade(request.getParameter("grade"));
					emp.setEmp_Designation(request.getParameter("designation"));
					emp.setEmp_Gender(request.getParameter("gender"));			
					emp.setEmp_Basic(Integer.parseInt(request.getParameter("basicSal")));
					emp.setEmp_Marital_Status(request.getParameter("marStat"));
					emp.setEmp_Home_Address(request.getParameter("homeAddr"));
					emp.setEmp_Contact_Num(request.getParameter("conNum"));
					
			break;
		
		}//outer switch
	}//method
}//servlet
