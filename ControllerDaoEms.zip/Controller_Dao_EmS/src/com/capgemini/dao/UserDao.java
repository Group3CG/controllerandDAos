package com.capgemini.dao;

import com.capgemini.exception.EmsException;

public interface UserDao {
	
	String usrCheck(String usrName,String usrPass) throws EmsException;

}
