package com.capgemini.dao;

import java.util.List;

import com.capgemini.dto.Employee;
import com.capgemini.exception.EmsException;


public interface EmployeeDao {
	
	public int addEmployee(Employee emp) throws EmsException;
	public List<Employee> showAllEmployees() throws EmsException;
	public void modifyEmployee(Employee emp) throws EmsException;

}
